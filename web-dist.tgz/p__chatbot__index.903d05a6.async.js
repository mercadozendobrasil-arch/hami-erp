"use strict";(self.webpackChunkhami_erp=self.webpackChunkhami_erp||[]).push([[3061],{18565:function(Ie,P,t){t.r(P),t.d(P,{default:function(){return pe}});var G=t(19632),W=t.n(G),X=t(97857),M=t.n(X),J=t(5574),g=t.n(J),Q=t(29177),Y=t(62839),w=t(2516),$=t(17412),q=t(46983),_=t(63254),ee=t(24533),te=t(18196),ne=t(66554),N=t(68997),ae=t(45416),v=t(67294),re=t(92099),se=t(72358),b,le=(b={NODE_ENV:"production",PUBLIC_PATH:"/"}.CHAT_API_URL)!==null&&b!==void 0?b:"https://api.x.ant.design/api/big_model_glm-4.5-flash",oe=function(){return new re.Z({request:(0,se.ZP)(le,{manual:!0,params:{model:"glm-4.5-flash",stream:!0}})})},ie=t(68400),l=t.n(ie),ue=t(91998),Z,E,O,R,L,U,B,F,z=(0,ue.kc)(function(f){var a=f.css,e=f.token;return{layout:a(Z||(Z=l()([`
    display: flex;
    flex: 1;
    overflow: hidden;
  `]))),sidebar:a(E||(E=l()([`
    width: 260px;
    background: `,`;
    border-right: 1px solid `,`;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  `])),e.colorBgContainer,e.colorBorderSecondary),main:a(O||(O=l()([`
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    min-width: 0;
    background: `,`;
  `])),e.colorBgContainer),messages:a(R||(R=l()([`
    flex: 1;
    overflow-y: auto;
    padding: `,`px;
    display: flex;
    flex-direction: column;
    align-items: center;

    > * {
      width: 100%;
    }
  `])),e.paddingMD),footer:a(L||(L=l()([`
    padding: `,`px;
    border-top: 1px solid `,`;
    display: flex;
    justify-content: center;
  `])),e.paddingMD,e.colorBorderSecondary),footerCenter:a(U||(U=l()([`
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: `,`px;
    gap: 32px;
    margin-top: -10%;
  `])),e.paddingLG),welcomeTitle:a(B||(B=l()([`
    font-size: 32px;
    font-weight: 600;
    color: `,`;
    text-align: center;
  `])),e.colorText),cursor:a(F||(F=l()([`
    animation: chatbot-blink 0.8s step-end infinite;

    @keyframes chatbot-blink {
      0%, 100% { opacity: 1; }
      50% { opacity: 0; }
    }
  `])))}}),n=t(85893),S="\u{1F916} \u4F60\u597D\uFF0C\u6709\u4EC0\u4E48\u53EF\u4EE5\u5E2E\u4F60\uFF1F",de=function(){var a=z(),e=a.styles,m=(0,v.useState)(0),o=g()(m,2),i=o[0],u=o[1],A=i>=S.length;return(0,v.useEffect)(function(){var p=setInterval(function(){u(function(d){return d>=S.length?(clearInterval(p),d):d+1})},80);return function(){return clearInterval(p)}},[]),(0,n.jsxs)(n.Fragment,{children:[S.slice(0,i),!A&&(0,n.jsx)("span",{className:e.cursor,children:"|"})]})},ce=function(a){var e=a.content,m=a.role;if(m!=="assistant")return{role:"user",content:e};var o=e.trimStart(),i=o.match(/^<think>([\s\S]*?)<\/think>([\s\S]*)$/);if(i)return{role:"assistant",thinkContent:i[1],content:i[2].trimStart()};var u=o.match(/^<think>([\s\S]*)$/);return u?{role:"assistant",thinkContent:u[1],content:""}:{role:"assistant",content:e}},ve={hasNextChunk:!0,enableAnimation:!0},fe={hasNextChunk:!1,enableAnimation:!0},he={user:{placement:"end",avatar:(0,n.jsx)(N.Z,{icon:(0,n.jsx)(Q.Z,{})})},ai:{placement:"start",avatar:(0,n.jsx)(N.Z,{style:{background:"transparent",fontSize:22,display:"flex",alignItems:"center",justifyContent:"center"},children:"\u{1F916}"}),typing:{effect:"typing",step:2,interval:20},contentRender:function(a,e){if(!(e!=null&&e.loading||!a))return(0,n.jsx)(te.Z,{streaming:(e==null?void 0:e.status)==="updating"?ve:fe,children:a})}}},me=function(){var a=z(),e=a.styles,m=(0,v.useState)([{key:"default",label:"\u{1F4AC} \u65B0\u5BF9\u8BDD",group:"\u4ECA\u5929",isDraft:!0},{key:"preset-1",label:"\u{1F9E9} Ant Design \u7684 Form \u8868\u5355\u5982\u4F55\u505A\u8054\u52A8\u6821\u9A8C\uFF1F",group:"\u4ECA\u5929"},{key:"preset-2",label:"\u{1F4CB} ProTable \u5982\u4F55\u81EA\u5B9A\u4E49\u5DE5\u5177\u680F\u6309\u94AE\uFF1F",group:"\u4ECA\u5929"},{key:"preset-3",label:"\u{1F3A8} \u5982\u4F55\u7528 antd-style \u5B9E\u73B0\u6697\u8272\u4E3B\u9898\u5207\u6362\uFF1F",group:"\u6628\u5929"},{key:"preset-4",label:"\u{1F5C2}\uFE0F ProLayout \u4FA7\u8FB9\u83DC\u5355\u5982\u4F55\u52A8\u6001\u751F\u6210\uFF1F",group:"\u6628\u5929"},{key:"preset-5",label:"\u{1F4CA} Ant Design Charts \u6298\u7EBF\u56FE\u6570\u636E\u683C\u5F0F",group:"\u6628\u5929"},{key:"preset-6",label:"\u{1F680} Ant Design Pro \u5982\u4F55\u63A5\u5165\u540E\u7AEF\u6743\u9650\u7CFB\u7EDF\uFF1F",group:"\u66F4\u65E9"},{key:"preset-7",label:"\u{1F50D} ProForm \u4E2D Select \u8FDC\u7A0B\u641C\u7D22\u600E\u4E48\u5B9E\u73B0\uFF1F",group:"\u66F4\u65E9"},{key:"preset-8",label:"\u2699\uFE0F Ant Design Token \u5B9A\u5236\u4E3B\u9898\u6700\u4F73\u5B9E\u8DF5",group:"\u66F4\u65E9"}]),o=g()(m,2),i=o[0],u=o[1],A=(0,v.useState)("default"),p=g()(A,2),d=p[0],y=p[1],ge=(0,v.useState)(""),H=g()(ge,2),ye=H[0],K=H[1],xe=(0,v.useMemo)(function(){return oe()},[]),x=(0,ne.Z)({provider:xe,conversationKey:d,parser:ce,requestPlaceholder:{role:"assistant",content:""}}),Ce=x.onRequest,je=x.abort,be=x.isRequesting,k=x.parsedMessages,Se=function(r){K(""),u(function(c){return c.map(function(s){return s.key===d&&s.isDraft?M()(M()({},s),{},{label:r.slice(0,20),isDraft:!1}):s})}),Ce({messages:[{role:"user",content:r}]})},Ae=function(){var r=crypto.randomUUID();u(function(c){return[{key:r,label:"\u65B0\u5BF9\u8BDD",group:"\u4ECA\u5929",isDraft:!0}].concat(W()(c))}),y(r)},ke=(0,v.useMemo)(function(){return k.map(function(h){var r=h.message,c=r.role==="assistant",s=r.role==="assistant"?r.thinkContent:void 0,C={key:h.id,role:c?"ai":"user",content:r.content,loading:c&&h.status==="loading",status:h.status};return c&&s&&(C.header=(0,n.jsx)(w.Z,{children:s})),C})},[k]),D=k.length>0;return(0,n.jsx)(Y._z,{ghost:!0,childrenContentStyle:{paddingBlock:0,height:"calc(100vh - 160px)",display:"flex",flexDirection:"column",overflow:"hidden"},children:(0,n.jsx)(ae.Z,{variant:"borderless",style:{height:"100%",display:"flex",flexDirection:"column",overflow:"hidden"},styles:{body:{flex:1,padding:0,overflow:"hidden",display:"flex",flexDirection:"column"}},children:(0,n.jsx)($.ZP,{children:(0,n.jsxs)("div",{className:e.layout,children:[(0,n.jsx)("div",{className:e.sidebar,children:(0,n.jsx)(q.Z,{items:i,activeKey:d,onActiveChange:y,groupable:!0,menu:function(r){return{items:[{key:"delete",label:"\u5220\u9664",danger:!0}],onClick:function(s){var C=s.key;C==="delete"&&u(function(De){var j=De.filter(function(Te){return Te.key!==r.key});if(j.length===0){var V=crypto.randomUUID();j.push({key:V,label:"\u{1F4AC} \u65B0\u5BF9\u8BDD",group:"\u4ECA\u5929",isDraft:!0}),y(V)}else if(d===r.key){var T,I;y((T=(I=j[0])===null||I===void 0?void 0:I.key)!==null&&T!==void 0?T:"")}return j})}}},creation:{onClick:Ae,label:"\u65B0\u5EFA\u5BF9\u8BDD"}})}),(0,n.jsxs)("div",{className:e.main,children:[D&&(0,n.jsx)("div",{className:e.messages,children:(0,n.jsx)(_.Z.List,{items:ke,role:he,autoScroll:!0,styles:{root:{maxWidth:940}}})}),(0,n.jsxs)("div",{className:D?e.footer:e.footerCenter,children:[!D&&(0,n.jsx)("div",{className:e.welcomeTitle,children:(0,n.jsx)(de,{})}),(0,n.jsx)(ee.Z,{value:ye,onChange:K,loading:be,onSubmit:Se,onCancel:je,placeholder:"\u8F93\u5165\u6D88\u606F\uFF0C\u6309 Enter \u53D1\u9001...",autoSize:{minRows:4,maxRows:8},style:{maxWidth:940,width:"100%"},styles:{input:{paddingBlock:0}}})]})]})]})})})})},pe=me}}]);
